window.onload = function() {
    let ime = prompt("Unesite vaše ime:");
    alert("Vaše ime je " + ime);
};
